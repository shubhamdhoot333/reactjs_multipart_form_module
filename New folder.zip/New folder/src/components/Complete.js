import React from 'react'

function Complete() {
    return (
        <div><h1> Sign up successfully </h1></div>
    )
}

export default Complete