import { useState } from 'react';

//phase 1
export function Point1({ increaseValue, getvalues }) {
    const initial = {
        name: '',
        gender: '',
        contact: '',
        dob: ''
    }
    const [user, setUser] = useState(initial);
    const onValueChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value })
    };
    const handleSubmit = async (e) => {
        e.preventDefault();
        // console.log("user add", user);
        if (user.name == "" || user.gender == "" || user.contact == "" || user.dob == "") {
            // console.log("filled empty");
            alert("filled empty! plz fill all fields ")

        }
        else {
            increaseValue();
            getvalues(user)
        }

    }
    return (
        <form onSubmit={handleSubmit}>
            <div className='row mt-5'>

                <div className='col-lg-4'></div>
                <div className='col-lg-4 border py-3' style={{ "paddingRight": "50px" }} >
                    <h4>Register</h4>
                    <h4>➊---------➁---------➂</h4>
                    <input type="text" className="form-control m-3" name="name" placeholder='Name' onChange={(e) => onValueChange(e)} />
                    <select name="gender" className="form-control m-3" onChange={(e) => onValueChange(e)}>
                        <option value="">Gender</option>
                        <option value="Male" name="gender" >Male</option>
                        <option value="Female" name="gender">Female</option>
                    </select>
                    <input type="text" className="form-control m-3" name="contact" placeholder='Contact No' onChange={(e) => onValueChange(e)} />
                    <input type="text" className="form-control m-3" name="dob" placeholder="Date of Birth " onChange={(e) => onValueChange(e)} />
                    <button type="submit" className=" text-white btn btn-warning btn-sm m-3" onChange={(e) => onValueChange(e)} style={{ "paddingLeft": "150px", "paddingRight": "180px" }}>Next</button>
                    <p> Already have a account ? SignIn </p>
                </div>
                <div className='col-lg-4'></div>
            </div>

        </form>
    )

}
