import { useState } from 'react';
//phase 2
export function Point2({ increaseValue, getvalues1 }) {
    const initial = {
        city: '',
        state: '',
        countary: '',
        postcode: ''
    }
    const [user, setUser] = useState(initial);
    const onValueChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value })
    };
    const handleSubmit = async (e) => {
        e.preventDefault();
        if (user.city == "" || user.state == "" || user.countary == "" || user.postcode == "") {
            alert("filled empty! plz fill all fields ")

        }
        else {
            increaseValue();
            getvalues1(user)
        }

    }
    return (
        <form onSubmit={handleSubmit}>
            <div className='row mt-5'>

                <div className='col-lg-4'></div>
                <div className='col-lg-4 border py-3' style={{ "paddingRight": "50px" }} >
                    <h4>Register </h4>
                    <h4>➀---------❷---------➂</h4>
                    <select name="city" className="form-control m-3" onChange={(e) => onValueChange(e)}>
                        <option value="">City</option>
                        <option value="Rampur" name="city" >Jaipur</option>
                        <option value="jodhpur" name="city">Jodhpur</option>
                    </select>
                    <select name="state" className="form-control m-3" onChange={(e) => onValueChange(e)}>
                        <option value="">State</option>
                        <option value="rajasthan" name="state" >rajasthan</option>
                        <option value="Up" name="state">UP</option>
                    </select>
                    <select name="countary" className="form-control m-3" onChange={(e) => onValueChange(e)}>
                        <option value="">Countary</option>
                        <option value="india" name="countary" >India</option>
                        <option value="uk" name="countary">Uk</option>
                    </select>
                    <input type="text" className="form-control m-3" name="postcode" placeholder='postcode' onChange={(e) => onValueChange(e)} />
                    <button type="submit" className=" text-white btn btn-warning btn-sm m-3" onChange={(e) => onValueChange(e)} style={{ "paddingLeft": "150px", "paddingRight": "180px" }}>Next</button>
                    <p> Already have a account ? SignIn </p>
                </div>
                <div className='col-lg-4'></div>
            </div>

        </form>
    )

}
