import { useState } from 'react';
//phase 3
export function Point3({ increaseValue, getvalues2 }) {
    const initial = {
        email: '',
        password: '',
        cpassword: ''
    }
    const [user, setUser] = useState(initial);
    const onValueChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value })
    };
    const handleSubmit = async (e) => {
        e.preventDefault();
        if (user.email == "" || user.password == "" || user.cpassword == "") {
            alert("filled empty! plz fill all fields ")

        }
        else {
            if (user.password == user.cpassword) {
                increaseValue();
                getvalues2(user);
            }
            else {
                alert("please enter same password and confirm password")
            }
        }


    }
    return (
        <form onSubmit={handleSubmit}>
            <div className='row mt-5'>

                <div className='col-lg-4'></div>
                <div className='col-lg-4 border py-3' style={{ "paddingRight": "50px" }} >
                    <h4>Register3 </h4>
                    <h4>➀---------➁---------❸</h4>
                    <input type="text" className="form-control m-3" name="email" placeholder='email' onChange={(e) => onValueChange(e)} />
                    <input type="password" className="form-control m-3" name="password" placeholder='Password' onChange={(e) => onValueChange(e)} />
                    <input type="password" className="form-control m-3" name="cpassword" placeholder="Confirm Password" onChange={(e) => onValueChange(e)} />
                    <button type="submit" className=" text-white btn btn-warning btn-sm m-3" onChange={(e) => onValueChange(e)} style={{ "paddingLeft": "150px", "paddingRight": "150px" }}>Complete</button>
                    <p> Already have a account ? SignIn </p>
                </div>
                <div className='col-lg-4'></div>
            </div>

        </form>
    )

}
