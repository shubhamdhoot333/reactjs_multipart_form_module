import React, { useState, useEffect } from 'react';
import { Point1 } from './Point1';
import { Point2 } from './Point2';
import { Point3 } from './Point3';
import Complete from './Complete';
function UserForms() {
    // eslint-disable-next-line
    const [step, setStep] = useState(1);
    const [data1, setData1] = useState('');
    const [data2, setData2] = useState('');
    const [data3, setData3] = useState('');
    const [fidata, setFidata] = useState("");
    useEffect(() => {

    }, [step])

    const combine = () => {
        let userData = { ...data1, ...data2, ...data3 }
        setFidata(userData);
        console.log(userData);


    }
    const increaseValue = () => {

        setStep(step + 1);


    }
    const getvalues = (fdata) => {
        setData1(fdata)
        console.log(fdata);
    }
    const getvalues1 = (fdata) => {
        setData2(fdata)
        console.log(fdata);
    }
    const getvalues2 = (fdata) => {
        setData3(fdata)
        console.log(fdata);
        combine()
    }
    // console.log(fidata);

    switch (step) {
        case 1:
            return (
                <Point1
                    increaseValue={increaseValue}
                    getvalues={getvalues}
                />
            );
        case 2:
            return (
                <Point2
                    increaseValue={increaseValue}
                    getvalues1={getvalues1}
                />
            );
        case 3:
            return (
                <Point3
                    increaseValue={increaseValue}
                    getvalues2={getvalues2} />
            );
        case 4:
            return (
                <Complete />
            )
        default:
            (console.log('This is a multi-step form built with React.'))
    }

}

export default UserForms